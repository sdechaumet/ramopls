#include <R.h>
#include <Rmath.h>
#include <math.h>
/*----------------------------------------------------------*/
void ckoplsKernelTrTr(double *x, int *nrow,int *ncol, double *param,double *kres){
  /*kres =  exp( -(sum((x1- x2)^2)) / (2*param^2) )*/
  int i,j,k,l,ccnt;
  double denom=2*pow(*param,2);
  //Rprintf("%f %i %i \n",denom,*ncol,*nrow);     
  for (i=0; i<*nrow; i++){
    for (j=i;j<*nrow;j++){
      //Rprintf("\n-----------\n");
      for(ccnt=0;ccnt<*ncol;ccnt++){ //for each column
	k=i+ccnt**nrow;
	l=j+ccnt**nrow;
	//Rprintf("%i %i %i %i \n", i, j,k,l);
	  if (k==i && l==j){	    
	    kres[i+j*(*nrow)]=0.00;
	  }
	  //Rprintf("current x %d %d %f %f \n",k, l, x[k],x[l]);
	  //Rprintf("kres %f \n",kres[i+j**nrow]);
	  kres[i+j**nrow]=kres[i+j**nrow]+pow(x[k]-x[l],2);
      }
      kres[i+j**nrow]=exp(-kres[i+j**nrow]/denom);
      //Rprintf("\n------end-----\n");
    }
   }
}
/*----------------------------------------------------------*/
void ckoplsKernelTrTe(double *x,double *x2, int *nrow,int *ncol,int *nrow2,int *ncol2, double *param,double *kres){
  /*kres =  exp( -(sum((x1- x2)^2)) / (2*param^2) )*/
  int i,j,k,l,ccnt;
  double denom=2*pow(*param,2);
  //Rprintf("%f %i %i \n",denom,*ncol,*nrow);     
  for (i=0; i<*nrow; i++){
    for (j=0;j<*nrow2;j++){
      //Rprintf("\n-----------\n");
      for(ccnt=0;ccnt<*ncol;ccnt++){ //for each column
	k=i+ccnt**nrow;
	l=j+ccnt**nrow2;
	//Rprintf("%i %i %i %i \n", i, j,k,l);
	  if (k==i && l==j){	    
	    kres[i+j*(*nrow)]=0.00;
	  }
	  //Rprintf("current x %d %d %f %f \n",k, l, x[k],x[l]);
	  //Rprintf("kres %f \n",kres[i+j**nrow]);
	  kres[i+j**nrow]=kres[i+j**nrow]+pow(x[k]-x2[l],2);
      }
      kres[i+j**nrow]=exp(-kres[i+j**nrow]/denom);
      //Rprintf("\n------end-----\n");
    }
   }
}
/*----------------------------------------------------------*/
/*----------------------------------------------------------*/
/*----------------------------------------------------------*/
/*----------------------------------------------------------*/
void ckoplsKernelPolynomialTrTr(double *x, int *nrow,int *ncol, double *param,double *kres){
	int i,j,k,l,ccnt;
	
	for (i=0; i<*nrow; i++){
		for (j=i;j<*nrow;j++){
			//Rprintf("\n-----------\n");
			for(ccnt=0;ccnt<*ncol;ccnt++){ //for each column
				k=i+ccnt**nrow;
				l=j+ccnt**nrow;
				//Rprintf("%i %i %i %i \n", i, j,k,l);
				if (k==i && l==j){	    
					kres[i+j*(*nrow)]=0.00;
				}
				//Rprintf("current x %d %d %f %f \n",k, l, x[k],x[l]);
				//Rprintf("kres %f \n",kres[i+j**nrow]);
				kres[i+j**nrow]=kres[i+j**nrow]+x[k]*x[l];
			}
			kres[i+j**nrow]=pow(kres[i+j**nrow]+1,*param);
			//Rprintf("\n------end-----\n");
		}
	}
}


/*----------------------------------------------------------*/
/*----------------------------------------------------------*/
void ckoplsKernelPolynomialTrTe(double *x,double *x2, int *nrow,int *ncol,int *nrow2,int *ncol2, double *param,double *kres){
  int i,j,k,l,ccnt;
  for (i=0; i<*nrow; i++){
    for (j=0;j<*nrow2;j++){
      //Rprintf("\n-----------\n");
      for(ccnt=0;ccnt<*ncol;ccnt++){ //for each column
	k=i+ccnt**nrow;
	l=j+ccnt**nrow2;
	//Rprintf("%i %i %i %i \n", i, j,k,l);
	  if (k==i && l==j){	    
	    kres[i+j*(*nrow)]=0.00;
	  }
	  //Rprintf("current x %d %d %f %f \n",k, l, x[k],x[l]);
	  //Rprintf("kres %f \n",kres[i+j**nrow]);
	  kres[i+j**nrow]=kres[i+j**nrow]+x[k]*x2[l];
      }
      kres[i+j**nrow]=pow(kres[i+j**nrow]+1,*param);
      //Rprintf("\n------end-----\n");
    }
   }
}
/*----------------------------------------------------------*/
