###########################################################################
#
# Centering function for the KteTe=Xte*Xte' kernel. Requires
# additional (un-centered) kernels.
#
# Authors: Max Bylesj�, Ume� University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesj�, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsCenterKTeTe<-function(KteTe,KteTr,KtrTr){

nte<-nrow(KteTr);
ntr<-ncol(KteTr);

Itrain<-diag(rep(1,ntr));
InTrain<-matrix(rep(1,ntr),ncol=1);
nTrain<-ntr;

I<-diag(rep(1,nte));
In<-matrix(rep(1,nte),ncol=1);
n<-nte;

Dte <- (1/nTrain)*In%*%t(InTrain);
KteTe <- KteTe -Dte%*%t(KteTr) - KteTr%*%t(Dte) + Dte%*%KtrTr%*%t(Dte);
return(KteTe);
}
