###########################################################################
#
# Calculates sensitivity and specificity in a class-wise fashion.
# * Input:
# trueClass = row vector of true class assignments (template)
# predClass = matrix (or row vector) of class assignments to be compared.
#
# *Output:
# Object with the class-specific and total sensitivity and specificity.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################


koplsSensSpec<-function(trueClass,predClass){



if(!is.data.frame(trueClass) || !is.matrix(trueClass)){
  trueClass<-as.matrix(trueClass);
}

if(!is.data.frame(predClass) || !is.matrix(predClass)){
  predClass<-as.matrix(predClass);
}

#if(dim(trueClass)!=NULL && dim(predClass)!=NULL && all(dim(trueClass)
  
 
#if class vectors, recreate 'dummy'....
  tmp1<-unique(as.vector(trueClass));
  tmp2<-unique(as.vector(predClass));
  
  if(ncol(trueClass)==1){
    trueClassDummy<-koplsDummy(trueClass);
    ## To make sure dummy is correct dimension for prediction data set
    predClassDummy<-koplsDummy(predClass, numClasses=ncol(trueClassDummy));
  }
  
#if(length(tmp1)==2 && length(tmp2)==2){
#  if(all(tmp1==c(0,1)) && all(tmp2==c(0,1))){
if(length(tmp1)==2){
  if(all(tmp1==c(0,1))){
    trueClassDummy<-(trueClass);
    predClassDummy<-(predClass);
  }
}

  

nclasses<-length(trueClassDummy[1,]);
results<-list(NULL);
if(length(predClassDummy[,1])!=length(trueClassDummy[,1]))
    stop('Different number of observations in predClass and trueClass');
    return;
end


resultsTot<-list(NULL);
resultsTot$TPtot<-0;
resultsTot$FPtot<-0;
resultsTot$TNtot<-0;
resultsTot$FNtot<-0;
resultsTot$Ntot<-0;
tmpSens<-NULL;
tmpSpec<-NULL;


    for(i in 1:nclasses){
        ind<-which(trueClassDummy[,i]==1); #true ind
        indPred<-which(predClassDummy[,i]==1); #pred ind
        indN<-which(trueClassDummy[,i]==0); #true ind
        indPredN<-which(predClassDummy[,i]==0); #pred
        
        results[[i]]<-list(NULL);
        results[[i]]$TP<-length(intersect(ind,indPred));
        results[[i]]$TN<-length(intersect(indN,indPredN));

        results[[i]]$N<-length(trueClassDummy[,i]);

        results[[i]]$FP<-length(setdiff(indPred,ind));
        results[[i]]$FN<-length(setdiff(indPredN,indN));
 
        results[[i]]$sens<-results[[i]]$TP/(results[[i]]$TP+results[[i]]$FN);
		if (!is.finite(results[[i]]$sens)) {
			results[[i]]$sens<-0;
		}
        results[[i]]$spec<-results[[i]]$TN/(results[[i]]$TN+results[[i]]$FP);
		if (!is.finite(results[[i]]$spec)) {
			results[[i]]$spec<-0;
		}
		
		tmpSens<-c(tmpSens,results[[i]]$sens);
		tmpSens[ which(!is.finite(tmpSens)) ]<-0;
		tmpSpec<-c(tmpSpec,results[[i]]$spec);
		tmpSpec[ which(!is.finite(tmpSpec)) ]<-0;
		
        results[[i]]$class<-i;
        
        #total
        resultsTot$TPtot<-resultsTot$TPtot+results[[i]]$TP;      
        resultsTot$FPtot<-resultsTot$FPtot+results[[i]]$FP;
        resultsTot$Ntot<-resultsTot$Ntot+results[[i]]$N;
        resultsTot$TNtot<-resultsTot$TNtot+results[[i]]$TN;
        resultsTot$FNtot<-resultsTot$FNtot+results[[i]]$FN;

        if(i==nclasses){#last class is done..
            resultsTot$sensTot<-resultsTot$TPtot/(resultsTot$TPtot+resultsTot$FNtot);
			if (!is.finite(resultsTot$sensTot)) { ## May actually happen
				resultsTot$sensTot<-0
			}
            resultsTot$specTot<-resultsTot$TNtot/(resultsTot$TNtot+resultsTot$FPtot);
			if (!is.finite(resultsTot$specTot)) {
				resultsTot$specTot<-0
			}
			
			resultsTot$meanSens<-mean(tmpSens);
			resultsTot$meanSpec<-mean(tmpSpec);
			
          }
      
      }

return(list(classResults=results,totalResults=resultsTot));
}
