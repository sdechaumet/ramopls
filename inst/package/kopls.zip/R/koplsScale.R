###########################################################################
#
# Scales a matrix.
# 
# * Input:
# X = X matrix (to be scaled)
# center = 'mc' for mean-centering, 'no' for no centering.
# scale = 'uv' for unit variance scaling, 'pareto' for Pareto scaling,
#	'none' for no scaling.
# 
# *Output:
# An object with the following properties:
# - center
# - scale
# - meanVector = vector with mean values for columns in X
# - stdvx = vector with standard deviations for columns in X
# - x = scaled X
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################


"koplsScale" <-
function(x,center='mc',scale='none'){
	#x is matrix
	#center=TRUE or FALSE  -mean centering
	#scale= 'uv', 'pareto or 'none'

	meanVector<-apply(x,2,'mean');
	sdevx<-NULL;

	if(as.logical(match(center,'mc',nomatch=0))){

		x<-x-matrix(rep(meanVector,nrow(x)),nrow=nrow(x),byrow=TRUE);
	}
	if(scale=='uv'){#scale to unit variance
		sdevx<-sd(x);	
		      
		x<-scale(x,center=FALSE,scale=sdevx);#((x)%*%diag(1/sdevx));
	}
	if(scale=='pareto'){#scale to unit variance
		sdevx<-sd(x);	       
		x<-scale(x,center=FALSE,scale=sqrt(sdevx));#(x) %*% diag(1/sqrt(sdevx));
	}

	return(list(x=x,meanVector=meanVector,sdVector=(sdevx),scale=scale,center=center));
}
