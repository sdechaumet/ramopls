###########################################################################
# 
# Converts integer vector to binary matrix (dummy matrix)
# class = vector with class belongings (int)
#
# Output: dummy = matrix (for K-OPLS-DA), class labels(columns) in ascending
#	order i.e. smallest class label will be as column one in dummy, etc.
#	labels_sorted=the class labels that are found in class in
#	sorted order.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

"koplsDummy" <-
function(class, numClasses=NA){
	#create a dummy matrix based on the vector Class that indicate
	#class
	rowNames<-rownames(class);
	if(is.data.frame(class)|is.matrix(class)){
		class<-as.vector(as.matrix(class));
	}

	if (is.na(numClasses))
	{
		uniqueClass<-unique(class);
		uniqueClass<-sort(uniqueClass);
	} else
	{
		uniqueClass<-1:numClasses
	}
	dummy<-matrix(0,nrow=length(class),ncol=length(uniqueClass));
	for(i in 1:length(uniqueClass)){
	      ind<-which(class==uniqueClass[i]);
	      dummy[ind,i]<-1;	      
	}
	rownames(dummy)<-rowNames;
	colnames(dummy)<-uniqueClass;
	return(dummy);
}#end createDummy
