###########################################################################
#
# Centering function for the KteTr=Xte*Xtr' kernel. Requires
# additional (un-centered) training kernel.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsCenterKTeTr<-function(KteTr,Ktrain){
  K<-KteTr; #Xtest*Xtrain';
  Kold<-K;

#Ktrain<-model.Kold;

#Mean Centering of K
#I_n <- vectors of length n containing only ones
#I <- identity matrix of same dimensionality as K
Itrain<-diag(rep(1,nrow(Ktrain)));#eye(length(Ktrain(:,1)));
InTrain<-matrix(rep(1,nrow(Ktrain)),ncol=1);#ones(length(Ktrain(:,1)),1);
nTrain<-nrow(Ktrain);#length(Ktrain(:,1));

I<-diag(rep(1,nrow(K)));#eye(length(K(:,1)));
In<-matrix(rep(1,nrow(K)),ncol=1);#ones(length(K(:,1)),1);
n<-nrow(K);#length(K(:,1));     

#this is the mean center step in feature space..
#K <- (I- (1/n).* I_n*I_n') * K*(I-(1/n).*I_n*I_n');
#true#

K <- (K- (1/nTrain)*(In%*%t(InTrain) %*% Ktrain)) %*% (Itrain-(1/nTrain)*InTrain%*%t(InTrain));
  return(K);
}
