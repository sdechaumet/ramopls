###########################################################################
#
# Kernel construction method. 
#
# *Input:
# X1 = the first X matrix (non-centered).
# X2 = the second X matrix (non-centered).
#  If X2 = NULL (empty set), then only X1 will be used for
#  the calculations. This way, only (n^2 - n)/2 instead of n^2
#  calculations have to be performed, which is typically much
#  faster. Only applicable for training kernels.
# Ktype = the type of kernel used. Supported entries are:
# - 'g': Gaussian kernel.
# - 'p': Polynomial kernel.
# param = A vector with parameter for the kernel function.
#   (Currently, all supported kernel functions use a scalar value
#    so the vector property of the parameters is for future
#    compability).
#
# *Output:
# K = The kernel.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################


koplsKernelR<-function(X1,X2=NA,Ktype,param){

fast.calc<-(is.na(X2[1]));
	
if (fast.calc) {
	K<-matrix(NA,ncol=nrow(X1),nrow=nrow(X1));
} else {
	K<-matrix(NA,ncol=nrow(X2),nrow=nrow(X1));
}
	
if(Ktype=='g'){ #gaussian
  #print('gaussian');
  sigma<-param[1]; #small value = overfit, larger = more general
	sigDenom<-(2* sigma^2);		
	
	if (fast.calc) {
          #print('fastcalc')
		for(i in 1:nrow(X1)){
				for( j in i:nrow(X1)){
		                  
                    ##K[i,j]<-exp( -(vectNorm(X1[i,]- X1[j,])^2) / (2* sigma^2) );#original and working
                    ##K[i,j]<-exp( -(sqrt(sum((X1[i,]- X1[j,])^2))^2) / (2* sigma^2) );#try to optimize v1
					K[i,j]<-exp( -(sum((X1[i,]- X1[j,])^2)) / sigDenom ); #try to optimize v2

					
					K[j,i]<-K[i,j]; #Due to symmetry
		        }
		}
		
	} else {
		for(i in 1:nrow(X1)){
				for( j in 1:nrow(X2)){
		                 
					##K[i,j]<-exp( -(vectNorm(X1[i,]- X2[j,])^2) / (2* sigma^2) ); #original and working
                    ##K[i,j]<-exp( -(sqrt(sum((X1[i,]- X1[j,])^2))^2) / (2* sigma^2) ); #try to optimize v1
					K[i,j]<-exp( -(sum((X1[i,]- X2[j,])^2)) / sigDenom ); #try to optimize v2


		        }

		}
		
	}
}



if(Ktype=='p'){ #polynomial, order=param
  #print('polynomial');
  porder<-param[1];
	if(porder%%1 !=0){
		stop(paste('Only integer valued order of polynomial kernel function is allowed, kernel parameter =',porder));
	}
	
  if (fast.calc) {
	
	for(i in 1:nrow(X1)){
	    for( j in i:nrow(X1)){
	      K[i,j]<-(t(X1[i,]) %*% (X1[j,])+1)^porder; #polynomial/homogenous
	      K[j,i]<-K[i,j]
	    }
	  }
  } else {
	  for(i in 1:nrow(X1)){
	    for( j in 1:nrow(X2)){
	      K[i,j]<-(t(X1[i,]) %*% (X2[j,])+1)^porder; #polynomial/homogenous
		}
	  }
	}
}

return(K);
}


vectNorm<-function(a){
	#return(c(sqrt(t(a) %*% a)));
	sqrt(sum(a^2));
}#end vectNorm
