###########################################################################
#
# Calculates the approximate area under the receiver operating
# characteristic curve to assess the classification performance.
# 
# * Input:
# data = matrix containing the predicted response matrix Y,
#   where columns denote classes and rows observations.
# trueclass = true class designation.
# 
# *Output:
# ROC = the sensitivities and 1-specificities for different thresholds
#       as well as the area under curve
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

"koplsRoc"<-function(data,trueclass){
if (dim(data)[2]>2|(length(unique(trueclass))>2)) {
    simpleError('ROC only possible for two-class problems')
}
ROC<-list()
classind<-unique(trueclass)
ind1<-which(trueclass==classind[1])
ind2<-which(trueclass==classind[2])
tmp<-data[,1]

a<-tmp[order(tmp)]
counter<-1
spec<-NULL
sens<-NULL
pred<-NULL
for (trs in a){
    pred<-matrix(2,length(tmp),1)
    bigind<-which(tmp>trs)
    pred[bigind]<-1
    tp=length(which(pred[ind1]==1))        
    tn=length(which(pred[ind2]==2))
    fn=length(which(pred[ind1]==2))
    fp=length(which(pred[ind2]==1))
    sens[counter]=tp/(tp+fn)
    spec[counter]=1-(tn/(tn+fp))
    counter=counter+1
}
ROC$sens=sens;
ROC$spec=spec;
ROC$AUC=sum((spec[1:(length(spec)-1)]-spec[2:length(spec)])*((sens[1:(length(sens)-1)]+sens[2:length(sens)])/2))
return(ROC)
}
