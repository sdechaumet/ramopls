###########################################################################
#
# Function for training a K-OPLS model.
# K = Kernel matrix
# Y = response matrix
# A = number of predictive components
# nox = number of Y-orthogonal components
# preProcK = pre-processing parameter for the K matrix.
#	'mc' for meancentering, 'no' for no centering.
# preProcY = pre-processing parameter for the Y matrix.
#	'mc' for mean-centering, 'uv' for mc + scaling to unit
#	variance, 'pa' for mc + Pareto, 'no' for no scaling.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsModel<-function(K,Y,A,nox,preProcK='mc',preProcY='mc'){

n=ncol(K);
#K<-centerK(K);
I<-diag(rep(1,n));


#[nn,kk]=size(K);
#I=eye(nn);

if (preProcK=='mc') {
	Kmc<-koplsCenterKTrTr(K);
} else {
	Kmc<-K;
}

K<-matrix(list(),ncol=nox+1,nrow=nox+1);
K[1,1]<-list(Kmc);

#%mean centering ---------------------
#% I=eye(length(K(:,1)));
#% I_n=ones(length(K(:,1)),1);
#% n=length(K(:,1));
#% 
#% %this is the mean center step in feature space..
#% Kmc = (I- (1/n).* I_n*I_n') * K*(I-(1/n).*I_n*I_n');
#% %Kold_mc=K;


## Pre-process Y
Y.old<-Y
scale.params<-list()
if (preProcY=='mc' | preProcY=='uv' | preProcY=='pareto') {
	scale.params<-koplsScale(Y, center='mc', scale=ifelse(preProcY=='mc','none',preProcY)  )
	Y<-scale.params$x
}


# initiate Yorth related vars
to<-list();
co<-list();
so<-list();
toNorm<-list();
Tp<-list();
Cp<-list();
Bt<-list();



# KOPLS model estimation -------------

#step 1
tmp<-svd(t(Y)%*%K[1,1][[1]]%*%Y,nu=A,nv=A)
#[Cp,Sp]=eigs(K,A);
Cp<-tmp$u;

if( A > 1){
  Sp<-diag(tmp$d[1:A]);
  Sps<-diag(tmp$d[1:A]^(-1/2)) #scaled version
}
else{
  Sp<-tmp$d[1];
  Sps<-tmp$d[1]^(-1/2) #scaled version
}
  
#step2
Up<-Y%*%Cp;

if (nox > 0) {
	for(i in 1:nox){ #Step3

	    #step4
	    Tp[[i]]<-t(K[1,i][[1]])%*%Up%*%Sps;    
	    Bt[[i]]<-solve(t(Tp[[i]])%*%Tp[[i]])%*%t(Tp[[i]])%*%Up;  
	    
	    #step5
	    #[CoTmp,SoTmp,Vo]
		#browser()
	    tmp<- svd( t(Tp[[i]])%*% (K[i,i][[1]]-Tp[[i]]%*%t(Tp[[i]]) )%*% Tp[[i]],nu=1,nv=1 );
	    

	    
	    co[[i]]<-tmp$u;
	    so[[i]]<-tmp$d[1];
	    
	    #step6
	    to[[i]]<-(K[i,i][[1]]-Tp[[i]]%*%t(Tp[[i]])) %*% Tp[[i]]%*%co[[i]]%*%so[[i]]^(-1/2);
	    
	    #step7
	    toNorm[[i]]<-c(sqrt(t(to[[i]])%*%to[[i]]));
	    
	    #step8
	    to[[i]]<-to[[i]]/toNorm[[i]];
	    
	    #step9
	    K[1,i+1][[1]]<-K[1,i][[1]]%*%(I - to[[i]]%*%t(to[[i]]));
	    
	    #step10
	    K[i+1,i+1][[1]]<-(I - to[[i]]%*%t(to[[i]])) %*% K[i,i][[1]]%*% (I - to[[i]]%*%t(to[[i]]));
	    
	    
	     
	} #step 11
}

#step12
Tp[[nox+1]]=t(K[1,nox+1][[1]])%*%Up%*%Sps;

#Step13
Bt[[nox+1]]=solve(t(Tp[[nox+1]]) %*% Tp[[nox+1]]) %*% t(Tp[[nox+1]])%*%Up;    

#---------- extra stuff -----------------
# should work but not fully tested (MB 2007-02-19)
sstotY <- sum(sum(Y*Y));
F<-Y-Up%*%t(Cp);
R2Y <- 1 - sum(sum( F*F))/sstotY;
#-------

EEprime<-K[nox+1,nox+1][[1]]-Tp[[nox+1]]%*%t(Tp[[nox+1]]);
sstotK <- sum(diag(K[1,1][[1]]));
R2X <- NULL;
R2XO <- NULL;
R2XC <- NULL;
R2Yhat <- NULL; # R2Yhat 22 Jan 2010 / MR

for (i in 1:(nox+1)){
    rss <- sum(diag( K[i,i][[1]]-Tp[[i]]%*%t(Tp[[i]]) ));    
    R2X <- c(R2X, 1 - rss/sstotK);
    
    rssc <- sum(diag( K[1,1][[1]]-Tp[[i]]%*%t(Tp[[i]]) ));    
    R2XC <- c(R2XC, 1 - rssc/sstotK );
    
    rsso <- sum(diag( K[i,i][[1]] ));    
    R2XO <- c(R2XO, 1 - rsso/sstotK );
	
	# R2Yhat 22 Jan 2010 / MR - not fully tested
	Yhat <- Tp[[i]] %*% Bt[[i]] %*% t(Cp);
	R2Yhat <- c(R2Yhat, 1 - sum(sum((Yhat-Y)^2))/sstotY);
  }


#----------------------------------------


model<-list();
model$Cp<-Cp;
model$Sp<-Sp;
model$Sps<-Sps;
model$Up<-Up;
model$Tp<-Tp;
model$T<-as.matrix(Tp[[nox+1]]);
model$co<-co;
model$so<-so;
model$to<-to;
if (nox > 0) {
	model$To<-matrix(nrow=nrow(model$T), ncol=nox, data=unlist(to), byrow=FALSE)
} else {
	model$To<-NULL
}
model$toNorm<-toNorm;
model$Bt<-Bt;
model$A<-A;
model$nox<-nox;
model$K<-K;

#extra stuff
model$EEprime<-EEprime;
model$sstot_K<-sstotK;
model$R2X<-R2X;
model$R2XO<-R2XO;
model$R2XC<-R2XC;
model$sstot_Y<-sstotY;
model$R2Y<-R2Y;
model$R2Yhat<-R2Yhat; # R2Yhat 22 Jan 2010 / MR

##Pre-processing
model$preProc<-list()
model$preProc$K<-preProcK
model$preProc$Y<-preProcY
model$preProc$paramsY<-scale.params


class(model)<-"kopls"

return(model);
}
