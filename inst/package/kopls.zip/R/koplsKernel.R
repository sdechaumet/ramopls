###########################################################################
#
# Kernel construction method. 
#
# *Input:
# X1 = the first X matrix (non-centered).
# X2 = the second X matrix (non-centered).
#  If X2 = NULL (empty set), then only X1 will be used for
#  the calculations. This way, only (n^2 - n)/2 instead of n^2
#  calculations have to be performed, which is typically much
#  faster. Only applicable for training kernels.
# Ktype = the type of kernel used. Supported entries are:
# - 'g': Gaussian kernel.
# - 'p': Polynomial kernel.
# param = A vector with parameter for the kernel function.
#   (Currently, all supported kernel functions use a scalar value
#    so the vector property of the parameters is for future
#    compability).
#
# *Output:
# K = The kernel.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################


koplsKernel<-function(X1,X2=NA,Ktype,param){

# CHECKING FOR IF DYNLIB IS LOADED TAKE A SIGNIFICANT AMOUNT OF CPU, SO NOT WORTH IT
#if(!is.loaded('ckoplsKernelTrTr') | !is.loaded('ckoplsKernelTrTe')){  # ADD FURTHER OBJECTS HERE if full test
#    warning('Compiled koplsKernel code not loaded, using slower R version...');
#    K<-koplsKernelR(X1,X2,Ktype,param)
#    return(K);
#  }

  
fast.calc<-(is.na(X2[1]));
	
if (fast.calc) {
	K<-matrix(NA,ncol=nrow(X1),nrow=nrow(X1));
} else {
	K<-matrix(NA,ncol=nrow(X2),nrow=nrow(X1));
}
	
if(Ktype=='g'){ #gaussian
  #print('gaussian');
  #dyn.load("koplsKernel.so")
  #library.dynam(chname="koplsKernel", package='kopls')
  sigma<-param[1]; #small value = overfit, larger = more general

	
	if (fast.calc) {
		K<-ckoplsKernelTrTr(x=X1,param=sigma);
	} else {
		K<-ckoplsKernelTrTe(x=X1,x2=X2,param=sigma);
		
	}
}

if(Ktype=='p'){ #polynomial, order=param
  #print('polynomial');
  porder<-param[1];
	if(porder%%1 !=0){
	  stop(paste('Only integer valued order of polynomial kernel function is allowed, kernel parameter =',porder));
	}	
	
  if (fast.calc) {
	  K<-ckoplsKernelPolynomialTrTr(x=X1,param=porder);
	  
	} else{
		K<-ckoplsKernelPolynomialTrTe(x=X1,x2=X2,param=porder);
	}
}

return(K);
}

##############################################
vectNorm<-function(a){
	#return(c(sqrt(t(a) %*% a)));
	sqrt(sum(a^2));
}#end vectNorm

##############################################
ckoplsKernelTrTe<-function(x,x2,param){
  kres<-matrix(rep(-99,nrow(x)*nrow(x2)),nrow=nrow(x));
  res<-.C("ckoplsKernelTrTe",x=as.double(x),x=as.double(x2),xnrow=as.integer(nrow(x)),xncol=as.integer(ncol(x)),xnrow2=as.integer(nrow(x2)),xncol2=as.integer(ncol(x2)),param=as.double(param),kres=as.double(kres),PACKAGE='kopls')
  res<-(matrix(res$kres,ncol=nrow(x2)));#re-create matrix
  return(res);
}
##############################################
##############################################
ckoplsKernelTrTr<-function(x,param){
  kres<-matrix(rep(-99,nrow(x)^2),ncol=nrow(x));
  res<-.C("ckoplsKernelTrTr",x=as.double(x),xnrow=as.integer(nrow(x)),xncol=as.integer(ncol(x)),param=as.double(param),kres=as.double(kres),PACKAGE='kopls')
  res<-(matrix(res$kres,ncol=nrow(x)));#re-create matrix
  res[res==c(-99)]<-0;#set missing values to 0, i.e. lower tri
  resdiag<-diag(res);# save diagonal entries
  tri<-upper.tri(res);#logical upper triangle
  res<-tri*res;#only upper triangle
  res<-res+t(res); # recreate lower triangle
  diag(res)<-resdiag; # replace diagonal entries
  return(res);
}
##############################################
ckoplsKernelPolynomialTrTr<-function(x,param){
	kres<-matrix(rep(-99,nrow(x)^2),ncol=nrow(x));
	res<-.C("ckoplsKernelPolynomialTrTr",x=as.double(x),xnrow=as.integer(nrow(x)),xncol=as.integer(ncol(x)),param=as.double(param),kres=as.double(kres),PACKAGE='kopls')
	res<-(matrix(res$kres,ncol=as.integer(nrow(x))));#re-create matrix
	res[res==c(-99)]<-0;#set missing values to 0
	resdiag<-diag(res);# save diagonal entries
	tri<-upper.tri(res);#logical upper triangle
	res<-tri*res;#only upper triangle
	res<-res+t(res); # recreate lower triangle
	diag(res)<-resdiag; # replace diagonal entries
	return(res);
}
##############################################
ckoplsKernelPolynomialTrTe<-function(x,x2,param){
	kres<-matrix(rep(-99,nrow(x)*nrow(x2)),nrow=nrow(x));
	res<-.C("ckoplsKernelPolynomialTrTe",x=as.double(x),x=as.double(x2),xnrow=as.integer(nrow(x)),xncol=as.integer(ncol(x)),xnrow2=as.integer(nrow(x2)),xncol2=as.integer(ncol(x2)),param=as.double(param),kres=as.double(kres),PACKAGE='kopls')
	res<-(matrix(res$kres,ncol=nrow(x2)));#re-create matrix
	return(res);
}
##############################################
