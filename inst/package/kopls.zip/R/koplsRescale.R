###########################################################################
#
# Scales a matrix based on pre-defined parameters from a scaling object.
#
# model = An object containing scaling parameters (see 'koplsScale()')
# x = If defined, this matrix will be scaled and returned.
#	Otherwise the original data set in the scaleS object will be scaled
#	and returned.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

"koplsRescale" <-
function(model,x=NA){
	#model is scaled object
	#rescales the matrix according to object info
	center=model$center;
	scale=model$scale;
	sdevx=model$sdVector;
	meanVector=model$meanVector;
	if(!all(is.na(x))){
          #print('mjrRescale():using x from arg');
		x<-x;
	}
	else{
		x<-model$x;
	}
	if (!is.null(scale)) {
	
		if(scale=='uv'){
			x<-scale(x,center=FALSE,scale=1/sdevx);#x<-((x)%*%diag(sdevx));
		}
		if(scale=='pareto'){#scale to unit variance
			x<-scale(x,center=FALSE,scale=1/sqrt(sdevx));#x<-((x)%*%diag(sqrt(sdevx)));
		}
	}
	if (!is.null(center)) {
		if(as.logical(match(center,'mc',nomatch=0))){
			x<-x+ matrix(rep(meanVector,nrow(x)),nrow=nrow(x),byrow=TRUE);
		}	
	}
	return(x);
}#end rescaleMe

