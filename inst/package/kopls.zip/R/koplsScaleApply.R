###########################################################################
#
# Applies scaling from external scaling objects ('see koplsScale()')
# on a matrix X.
# 
# * Input:
# model = An object containing scaling parameters (see 'koplsScale()')
# x = X matrix (to be scaled)
# 
# *Output:
# An object with e.g. the following properties:
# - x = scaled X
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################


"koplsScaleApply" <-
function(model,x){
	#model is the scaled data set
	#x is the new matrix to apply scaling to
	center=model$center;
	scale=model$scale;
	sdevx=model$sdVector;
	meanVector=model$meanVector;

	if(as.logical(match(center,'mc',nomatch=0))){
		x<-x-matrix(rep(meanVector,nrow(x)),nrow=nrow(x),byrow=TRUE);
	}
	if(scale=='uv'){#scale to unit variance
				x<-scale(x,center=FALSE,scale=sdevx);#x<-((x)%*%diag(1/sdevx));
			}
	if(scale=='pareto'){#scale to pareto variance
				x<-scale(x,center=FALSE,scale=sqrt(sdevx));#x<-((x)%*%diag(sqrt(1/sdevx)));
	}
	
	return(list(x=x,meanVector=meanVector,sdVector=sdevx,scale=scale,center=center));
	
}

